
package ex01manip;

import java.util.Scanner;

public class Ex01Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String palavrinha_maxica;
        System.out.println("Digite uma palavrinha maxica: ");
        palavrinha_maxica = teclado.nextLine();
        int caracteres = palavrinha_maxica.length();
        System.out.println("A palavrinha maxica tem " + caracteres + " caracteres");
    }
    
}
