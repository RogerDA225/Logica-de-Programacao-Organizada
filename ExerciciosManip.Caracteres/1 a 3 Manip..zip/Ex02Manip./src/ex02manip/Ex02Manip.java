
package ex02manip;

import java.util.Scanner;

public class Ex02Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String frase;
        int quantidade_vogais = 0;
        System.out.println("Informe a frase: ");
        frase = teclado.nextLine();
        for (int i = 0; i < frase.length(); i++) {
            if (frase.charAt(i) == 'A' || frase.charAt(i) == 'E' || frase.charAt(i) == 'I' || frase.charAt(i) == 'O' || frase.charAt(i) == 'U' || frase.charAt(i) == 'a' || frase.charAt(i) == 'e' || frase.charAt(i) == 'i' || frase.charAt(i) == 'o' || frase.charAt(i) == 'u') {
                quantidade_vogais++;
            }
        }
        System.out.println("A frase tem " + quantidade_vogais + " vogais");
    }
    
}
