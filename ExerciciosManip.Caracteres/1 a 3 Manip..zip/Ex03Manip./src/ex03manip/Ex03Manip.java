
package ex03manip;

import java.util.Scanner;

public class Ex03Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String frase;
        System.out.println("Digite a frase: ");
        frase = teclado.nextLine();
        String resp[] = frase.split(" ");
        System.out.println("A quantidade de palavras: " + resp.length);
        
    }
    
}
