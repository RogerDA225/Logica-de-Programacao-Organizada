package ex04manip;

import java.util.Scanner;

public class Ex04Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome;
        System.out.println("Digite seu nome completo: ");
        nome = teclado.nextLine();
        String resp[] = nome.split(" ");
        System.out.println("O seu primeiro nome eh: " + resp[0]);
    }

}
