package ex05manip;

import java.util.Scanner;

public class Ex05Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String data;
        System.out.println("Digite a data no formato dd/mm/aaaa");
        data = teclado.nextLine();
        String data_separada[] = data.split("/");
        int ano = Integer.parseInt(data_separada[2]);
        System.out.println("O proximo ano eh: " + (ano+1));
    }

}
