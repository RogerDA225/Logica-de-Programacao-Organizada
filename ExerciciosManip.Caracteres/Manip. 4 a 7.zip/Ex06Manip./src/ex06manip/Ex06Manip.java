
package ex06manip;

import java.util.Scanner;

public class Ex06Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome;
        System.out.println("Digite seu nome completo: ");
        nome = teclado.nextLine();
        String nome_separado[] = nome.split(" ");
        System.out.print(nome_separado[nome_separado.length - 1] + ",");
        for (int i = 0; i < nome_separado.length - 1; i++) {
            System.out.print(" " + nome_separado[i]);
        }
                
    }
    
}
