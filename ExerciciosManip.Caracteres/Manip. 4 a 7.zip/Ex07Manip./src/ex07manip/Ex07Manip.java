
package ex07manip;

import java.util.Scanner;

public class Ex07Manip {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome;
        System.out.println("Digite seu nome: ");
        nome = teclado.nextLine();
        String nome_separado[] = nome.split(" ");
        String nome_abreviado[] = new String [nome_separado.length];
        for (int i = 0; i < nome_separado.length; i++) {
            if (i == 0 || i == nome_separado.length - 1) {
                nome_abreviado[i] = nome_separado[i];
            } else {
                nome_abreviado[i] = nome_separado[i].charAt(0) + ".";
            }
        }
        
        for (int i = 0; i < nome_abreviado.length; i++) {
            System.out.print(nome_abreviado[i] + " ");
        }
    }
    
}
